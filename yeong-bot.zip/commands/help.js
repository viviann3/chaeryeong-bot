module.exports = {
  type:"basicCommand" ,
  name:"help" ,
  code: `
  $author[1;Command Center;$authorAvatar]
  $description[1;All **__available__** commands for this bot. Join **https://dsc.gg/yeong** for further assistance]
  $addField[1;__Basic__;\`\`\`Drop\n Profile\n Cooldowns\n Balance\`\`\`;yes]
  $addField[1;__Carding__;\`\`\`Drop\n Inventory\n Fuse\n Burn\`\`\`;yes]
  $addField[1;__Miscellanous__;\`\`\`Help\n Bio\n Favgroup\n Favcard\n Collection\`\`\`;yes]
  $addField[1;__Notes__;‣ Prefix is \`>\`
  ‣ dsc.gg/yeong is the support server
  ‣ guide: yeong.iucord.ml (chaeryeong is the sister bot of IU)]
  $color[1;#2F3136]
  $image[1;https://pa1.narvii.com/7315/08cf985e5a48a57ceb49d1a997b250f6af6514c0r1-444-250_hq.gif]`
}