module.exports = {
  type:"basicCommand" ,
  name:"collection" ,
  aliases:['col' , 'c'] ,
  code: `
  $onlyIf[$message!=;:x: Please enter a valid group (or soloist)!]
  $author[1;Collection;$authorAvatar]
  $color[1;#2F3136]
  $if[$message==itzy]
  $description[1;Here is your collection of **ITZY**!]
  `
}