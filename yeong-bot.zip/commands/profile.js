module.exports = {
  type:"basicCommand" ,
  name:"profile" ,
  aliases:['p' , 'pr'] ,
  code: `
  $author[1;Profile;$authorAvatar]
  $description[1;👥 **User**: <@$authorID>\n :cd: (CDs): yes i'll dp this later thasiuhdj]
  $addField[1;Stats;:bar_chart: Average Card Stats: ||not yet||\n :flower_playing_cards: Favorite card: ||not yet||\n :abacus: Collections Completed: ||not yet||]
  $thumbnail[1;$authorAvatar]
  $color[1;#2F3136]`
}