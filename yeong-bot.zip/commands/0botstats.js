module.exports = {
  type:"basicCommand" , 
  name:"botstats" ,
  code: `
  $author[1;Bot Stats;$authorAvatar]
  $thumbnail[1;$authorAvatar]
  $addField[1;Developer (UID);821645787297218572]
  $addField[1;Version;0.0.1 (Alpha Testing)]
  $addField[1;Servers;$serverCount]
  $addField[1;Uptime;$uptime]
  $addField[1;CPU;$cpu/100]
  $addField[1;RAM;$ramMB]
  $color[1;#2F3136]
  `
}